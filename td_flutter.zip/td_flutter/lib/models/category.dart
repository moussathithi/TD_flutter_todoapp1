


enum Category{
   Business,
   Personnal
}